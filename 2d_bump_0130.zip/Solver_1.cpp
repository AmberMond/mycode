#include "Solver_1.hpp"
#include <iostream>
#include <cmath>

Solver::Solver(const Mesh& m) : mesh(m) {
    U_current.resize(mesh.cells.size());
    Residuals.resize(mesh.cells.size());
}

void Solver::setFlowConditions(double M_inf_in, double P_ref, double T_ref) {
    // calculate total pressure and temperature at inlet
    // T0 = T * (1 + (gamma-1)/2 * M^2)
    // P0 = P * (1 + (gamma-1)/2 * M^2)^(gamma/(gamma-1))
   
    M_inf = M_inf_in;	
    double factor_T = 1.0 + 0.5 * (gamma - 1.0) * M_inf * M_inf;
    double factor_P = std::pow(factor_T, gamma / (gamma - 1.0));

    // inlet 
    T_total_inlet = T_ref * factor_T;
    P_total_inlet = P_ref * factor_P;

    // outlet
    P_static_exit = P_ref;

    std::cout << "--- Flow Conditions Set ---" << std::endl;
    std::cout << "Mach: " << M_inf << std::endl;
    std::cout << "Inlet P0: " << P_total_inlet << ", T0: " << T_total_inlet << std::endl;
    std::cout << "Outlet P_static: " << P_static_exit << std::endl;
}

void Solver::initialize() {
    // inititalize : uniform flow
    
    double p = P_static_exit;
    // T = T0 / (1 + (g-1)/2 * M^2) 
    double factor_T = std::pow(P_total_inlet / p, (gamma - 1.0) / gamma); // Isentropic relation
    double T = T_total_inlet / factor_T;
    
    double rho = p / (R_gas * T);
    double c = std::sqrt(gamma * R_gas * T);
    
    // u^2 = M^2 * c^2 
    double V = std::sqrt(2.0 * (gamma * R_gas / (gamma - 1.0)) * (T_total_inlet - T));
    
    
    State init = primitiveToConservative(rho, V, 0.0, p);
    std::fill(U_current.begin(), U_current.end(), init);
    
    std::cout << "Field initialized with M=" << V/c << ", P=" << p << std::endl;
}

State Solver::primitiveToConservative(double rho, double u, double v, double p) {
    double rhoE = p / (gamma - 1.0) + 0.5 * rho * (u * u + v * v);
    return State(rho, rho * u, rho * v, rhoE);
}

void Solver::computeResiduals(const std::vector<State>& U_in, std::vector<State>& R_out) {
    std::fill(R_out.begin(), R_out.end(), State(0,0,0,0));

    for (const auto& f : mesh.faces) {
        State UL = U_in[f.owner];
        State Flux;

        if (f.neighbor >= 0) {
            // internal face
            State UR = U_in[f.neighbor];
            Flux = computeFluxLLF(UL, UR, f.nx, f.ny);
            double mag = f.area;
            R_out[f.owner] = R_out[f.owner] + Flux * mag;
            R_out[f.neighbor] = R_out[f.neighbor] - Flux * mag;
        } else {
            // boundary face
            State U_ghost = getBoundaryGhostState(UL, f);
            Flux = computeFluxLLF(UL, U_ghost, f.nx, f.ny);
            R_out[f.owner] = R_out[f.owner] + Flux * f.area;
        }
    }
}

// set boundary ghost state
State Solver::getBoundaryGhostState(const State& U_in, const Face& f) {
    State U_ghost = U_in;

    // --- BC Tag 1: Subsonic Inlet (Given P0, T0) ---
    if (f.bcTag == 1) {
        
        
        double p_in = getPressure(U_in);
        
        // avoid NaN value
        double p_use = std::min(p_in, P_total_inlet - 1e-4); 

        //Isentropic relations:
        // T = T0 * (P/P0)^((g-1)/g)
        double T_ghost = T_total_inlet * std::pow(p_use / P_total_inlet, (gamma - 1.0) / gamma);
        double rho_ghost = p_use / (R_gas * T_ghost);
        
        // Velocity magnitude from Energy equation: V^2 = 2Cp(T0 - T)
        double Cp = gamma * R_gas / (gamma - 1.0);
        double V2 = 2.0 * Cp * (T_total_inlet - T_ghost);
        double V = (V2 > 0) ? std::sqrt(V2) : 0.0;

       
        U_ghost = primitiveToConservative(rho_ghost, V, 0.0, p_use);
    }
    // --- BC Tag 2: Outlet (Given Static Pressure) ---
    else if (f.bcTag == 2) {
        // subsonic outlet P_exit
        
        double p_target = P_static_exit;
        
        double rho = U_in.rho;
        double u = U_in.rhou / U_in.rho;
        double v = U_in.rhov / U_in.rho;
        
        // set others
        U_ghost = primitiveToConservative(rho, u, v, p_target);
    }
    // --- BC Tag 3: Slip Wall ---
    else if (f.bcTag == 3) {
        
        double u = U_in.rhou / U_in.rho;
        double v = U_in.rhov / U_in.rho;
        
        double vn = u * f.nx + v * f.ny;
        
        // V_ghost
        double u_g = u - 2.0 * vn * f.nx;
        double v_g = v - 2.0 * vn * f.ny;
        
        U_ghost.rho = U_in.rho;
        U_ghost.rhou = U_in.rho * u_g;
        U_ghost.rhov = U_in.rho * v_g;
        U_ghost.rhoE = U_in.rhoE; 
    }

    return U_ghost;
}

void Solver::timeStepExplicit(double dt) {
    computeResiduals(U_current, Residuals);
    static int exp_step = 0;
    exp_step++;
    if (exp_step % 100 == 0){
        double currentNorm = norm_L2(Residuals);
        std::cout << "Explict Step" << exp_step << "| Residual Norm:" << currentNorm << std::endl;
    }
    for (int i = 0; i < mesh.cells.size(); ++i) {
        double vol = mesh.cells[i].volume;
        U_current[i] = U_current[i] - Residuals[i] * (dt / vol);
    }
}




// Linear Algebra


double Solver::norm_L2(const std::vector<State>& v) const {
    double sum = 0.0;
    for (const auto& s : v) {
        sum += s.rho*s.rho + s.rhou*s.rhou + s.rhov*s.rhov + s.rhoE*s.rhoE;
    }
    return std::sqrt(sum);
}

double Solver::dot_product(const std::vector<State>& a, const std::vector<State>& b) const {
    double sum = 0.0;
    for (size_t i = 0; i < a.size(); ++i) {
        sum += a[i].rho*b[i].rho + a[i].rhou*b[i].rhou + a[i].rhov*b[i].rhov + a[i].rhoE*b[i].rhoE;
    }
    return sum;
}


// residual convergence

double Solver::getTotalVolume() const{
    double totalVol = 0.0;
    for (const auto& c : mesh.cells) {
        totalVol += c.volume;
    }
    return totalVol;
}


// L2 norm

double Solver::norm_L2_VolumeWeighted(const std::vector<State>& R) const {
    double sum_sq = 0.0;
    double total_vol = 0.0;

    for (size_t i = 0; i < R.size(); ++i){
        double vol = mesh.cells[i].volume;
        const auto& r = R[i];

        double rho_res = r.rho / vol;
        double u_res = r.rhou / vol;
        double v_res = r.rhov / vol;
        double E_res = r.rhoE / vol;

        double local_sq = rho_res*rho_res + u_res*u_res + v_res*v_res + E_res*E_res;

        sum_sq += local_sq * vol;
        total_vol += vol;
    }
    if (total_vol == 0) return 0.0;
    return std::sqrt(sum_sq / total_vol);

}

// drag effiecient

void Solver::calculateDrag(){
    double drag = 0.0;
    double lift = 0.0;

    int wallTag = 3;

    for (const auto& f : mesh.faces){
        if (f.bcTag == wallTag){
            State U = U_current[f.owner];
            double p = getPressure(U);

            double Fx = -p * f.area * f.nx;
            double Fy = -p * f.area * f.ny;
            
            drag += Fx;
            lift += Fy;
        }
    }

    std::cout << " Drag :" << drag << " Lift: " << lift << std::endl;
}

// ------------------------------------------------------------------
// JFNK Core: Jacobian-Vector Product
// ------------------------------------------------------------------

void Solver::applyJacobian(const std::vector<State>& U_base, 
                           const std::vector<State>& R_base,
                           const std::vector<State>& v, 
                           std::vector<State>& Jv) {
    // 1. Determine perturbation epsilon
    // Simple strategy: eps = 1e-6
    double epsilon = 1e-5; 
    
    // Ideally, eps should be scaled: eps = b / ||v||
    // double v_norm = norm_L2(v); 
    // if(v_norm > 1e-12) epsilon = 1e-6 / v_norm;

    // 2. Perturb State: U_pert = U + eps * v
    int N = U_base.size();
    std::vector<State> U_pert(N);
    for(int i=0; i<N; ++i) {
        U_pert[i] = U_base[i] + v[i] * epsilon;
    }

    // 3. Compute Residual at Perturbed State: R(U + eps*v)
    std::vector<State> R_pert(N);
    computeResiduals(U_pert, R_pert);

    // 4. Finite Difference: Jv = (R_pert - R_base) / eps
    // Note: We are solving J * dU = -R. If Residual R is defined as RHS... 
    // Usually Implicit Eq: (U_new - U_old)/dt + R(U_new) = 0
    // Jacobian J = I/dt + dR/dU
    // Here we compute dR/dU * v first.
    
    // For pure steady state JFNK (infinite time step, dt -> inf):
    // J = dR/dU.
    // Jv approx [R(U+ev) - R(U)] / e
    
    for(int i=0; i<N; ++i) {
        Jv[i] = (R_pert[i] - R_base[i]) * (1.0 / epsilon);
    }
}

// ------------------------------------------------------------------
// GMRES Solver
// Solves A * x = b, where A is Jacobian matrix operator
// ------------------------------------------------------------------

int Solver::solveGMRES(const std::vector<State>& U_base, 
                       const std::vector<State>& RHS, // This is usually -Residual(U_base)
                       std::vector<State>& x) { // x is delta_U (output)
    
    // int m = 15; // Krylov subspace size (Restart parameter)
    int m = 40;
    int max_iter = 2; // Number of restarts (keep small for Newton steps)
    int N = U_base.size();
    
    // Pre-calculate R(U_base) for JFNK usage (it usually equals -RHS)
    std::vector<State> R_base(N);
    // Since RHS = -R(U), then R(U) = -RHS
    for(int i=0; i<N; ++i) R_base[i] = RHS[i] * (-1.0); 

    // Vectors for Arnoldi process
    // V[i] is the i-th basis vector
    std::vector<std::vector<State>> V(m + 1, std::vector<State>(N)); 
    
    // Hessenberg matrix H (m+1 x m) stored in 1D or 2D. 
    // Small matrix, use simple 2D vector
    std::vector<std::vector<double>> H(m + 1, std::vector<double>(m, 0.0));

    // Rotations for QR decomposition
    std::vector<double> sn(m, 0.0);
    std::vector<double> cs(m, 0.0);
    
    // Algorithm start
    // Initial guess x = 0 (delta_U starts at 0)
    std::fill(x.begin(), x.end(), State(0,0,0,0));

    // Residual vector r = b - A*x0 -> since x0=0, r = b (= RHS)
    std::vector<State> r = RHS;
    double beta = norm_L2(r);
    
    if (beta < 1e-12) return 0; // Already converged

    V[0] = r;
    // Normalize V[0] = r / beta
    double invBeta = 1.0 / beta;
    for(int i=0; i<N; ++i) V[0][i] = V[0][i] * invBeta;

    // RHS of the small least squares problem g = [beta, 0, 0, ...]^T
    std::vector<double> g(m + 1, 0.0);
    g[0] = beta;

    // Arnoldi Iteration
    int k = 0;
    for (int j = 0; j < m; ++j) {
        k = j;
        
        // 1. Compute w = A * V[j] (Matrix-Vector Product)
        // Here A is the Jacobian J approx
        applyJacobian(U_base, R_base, V[j], V[j+1]); // Store result temporarily in V[j+1]

        // 2. Gram-Schmidt Orthogonalization
        for (int i = 0; i <= j; ++i) {
            H[i][j] = dot_product(V[j+1], V[i]); // h_ij = (Av_j, v_i)
            // w = w - h_ij * v_i
            for(int idx=0; idx<N; ++idx) {
                V[j+1][idx] = V[j+1][idx] - V[i][idx] * H[i][j];
            }
        }
        
        H[j+1][j] = norm_L2(V[j+1]); // h_{j+1, j} = ||w||

        // 3. Normalize next basis vector
        if (H[j+1][j] > 1e-12) { // breakdown check
            double invH = 1.0 / H[j+1][j];
            for(int idx=0; idx<N; ++idx) {
                V[j+1][idx] = V[j+1][idx] * invH;
            }
        }

        // 4. Apply Givens Rotation to preserve Hessenberg structure
        // Previous rotations
        for (int i = 0; i < j; ++i) {
            double temp = cs[i] * H[i][j] + sn[i] * H[i+1][j];
            H[i+1][j] = -sn[i] * H[i][j] + cs[i] * H[i+1][j];
            H[i][j] = temp;
        }
        // New rotation
        double a = H[j][j];
        double b = H[j+1][j];
        // Calculate rotation parameters
        if (std::abs(b) < 1e-14) {
            cs[j] = 1.0; sn[j] = 0.0;
        } else {
            double t = std::sqrt(a*a + b*b);
            cs[j] = a / t;
            sn[j] = b / t;
        }
        // Apply new rotation
        H[j][j] = cs[j] * a + sn[j] * b;
        H[j+1][j] = 0.0;
        
        // Update RHS 'g'
        g[j+1] = -sn[j] * g[j];
        g[j]   = cs[j] * g[j];

        // Check convergence based on residual of small system (g[j+1])
        if (std::abs(g[j+1]) < 1e-4 * beta) break; 
    }

    // Solve upper triangular system Hy = g
    std::vector<double> y(k + 1);
    for (int i = k; i >= 0; --i) {
        y[i] = g[i];
        for (int l = i + 1; l <= k; ++l) {
            y[i] -= H[i][l] * y[l];
        }
        y[i] /= H[i][i];
    }

    // Form solution x = x0 + V_m * y
    // x += sum(y[i] * V[i])
    for (int i = 0; i <= k; ++i) {
        for(int idx=0; idx<N; ++idx) {
            x[idx] = x[idx] + V[i][idx] * y[i];
        }
    }
    
    return k + 1;
}

void Solver::calculateEntropyError() {
    double T_inf = T_total_inlet / (1.0 + 0.5*(gamma-1.0)*M_inf*M_inf);
    double P_inf = P_total_inlet / std::pow(1.0 + 0.5*(gamma-1.0)*M_inf*M_inf, gamma/(gamma-1.0));

    double rho_inf = P_inf / (R_gas * T_inf);
    double S_ref = P_inf / std::pow(rho_inf, gamma);
    double sum_error_sq_vol = 0.0;
    double total_vol = 0.0;

    for (size_t i = 0; i < mesh.cells.size(); ++i) {
        State U = U_current[i];
        double p = getPressure(U);
        double rho = U.rho;
        if (p <= 0 || rho <= 0) continue;

        double S_local = p/std::pow(rho, gamma);
        double error = (S_local - S_ref) / S_ref;
        sum_error_sq_vol += (error * error) * mesh.cells[i].volume;
        total_vol += mesh.cells[i].volume;
    }

    double L2_Entropy_Error = std::sqrt(sum_error_sq_vol / total_vol);

    std::cout << " GRS " << std::endl;
    std::cout << " Cells: " << mesh.cells.size() << std::endl;
    std::cout << " L2 Entropy Error: " << L2_Entropy_Error << std::endl; 
}

// ------------------------------------------------------------------
// Newton Solver Interface
// ------------------------------------------------------------------

void Solver::solveImplicit(double tolerance, int maxSteps) {
    std::cout << "--- Starting JFNK Implicit Solver ---" << std::endl;
    int N = mesh.cells.size();
    
    // Newton Loop
    for (int step = 0; step < maxSteps; ++step) {
        // 1. Calculate Residual R(U^k)
        computeResiduals(U_current, Residuals);
        
        // Check convergence (L2 norm of all density residuals)
        double resNorm = norm_L2(Residuals);
        double normalizedRes = resNorm / std::sqrt(static_cast<double>(mesh.cells.size()));
        std::cout << "Newton Step " << step << " | Abs Residual Norm: " << resNorm 
                  << " | Normalized Residual Norm: " << normalizedRes << std::endl;
        
        if (resNorm < tolerance) {
            std::cout << "Converged!" << std::endl;
            break;
        }

        // 2. Solve Linear System J * dU = -R
        // RHS = -R
        std::vector<State> RHS(N);
        for(int i=0; i<N; ++i) RHS[i] = Residuals[i] * (-1.0);
        
        std::vector<State> delta_U(N); // Update vector
        
        // Call GMRES
        solveGMRES(U_current, RHS, delta_U);

        // 3. Update U^{k+1} = U^k + delta_U
        // (Optional: perform Line Search here to ensure residual decreases)
        // Simple full step:
        double relaxation = 0.5; // Under-relaxation often helps stability initially
        for(int i=0; i<N; ++i) {
            U_current[i] = U_current[i] + delta_U[i] * relaxation;
        }
    }
}
