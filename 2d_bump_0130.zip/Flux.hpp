#ifndef FLUX_HPP
#define FLUX_HPP

#include <cmath>
#include <algorithm>
#include "Types.hpp" //

// constant
const double GAMMA = 1.4;

// p
inline double getPressure(const State& U) {
    double V2 = (U.rhou * U.rhou + U.rhov * U.rhov) / (U.rho * U.rho);
    return (GAMMA - 1.0) * (U.rhoE - 0.5 * U.rho * V2);
}

// soundspeed
inline double getSoundSpeed(double p, double rho) {
    return std::sqrt(GAMMA * p / rho);
}

// normal vector: F_n(U)
inline State computeNormalFlux(const State& U, double nx, double ny) {
    double p = getPressure(U);
    double u = U.rhou / U.rho;
    double v = U.rhov / U.rho;
    double un = u * nx + v * ny; // normal velocity

    return State(
        U.rho * un,
        U.rhou * un + p * nx,
        U.rhov * un + p * ny,
        (U.rhoE + p) * un
    );
}

// LLF numerical flux function

// Inputs: left state UL, right state UR, face normal vector (nx, ny)
// Output: flux vector
inline State computeFluxLLF(const State& UL, const State& UR, double nx, double ny) {
    // 1. Compute left and right physical fluxes
    State FL = computeNormalFlux(UL, nx, ny);
    State FR = computeNormalFlux(UR, nx, ny);

    // 2. Compute wave speeds (eigenvalues)
    double pL = getPressure(UL);
    double uL = UL.rhou / UL.rho; 
    double vL = UL.rhov / UL.rho;
    double unL = uL * nx + vL * ny;
    double cL = getSoundSpeed(pL, UL.rho);

    double pR = getPressure(UR);
    double uR = UR.rhou / UR.rho; 
    double vR = UR.rhov / UR.rho;
    double unR = uR * nx + vR * ny;
    double cR = getSoundSpeed(pR, UR.rho);

    // alpha = max(|un| + c)
    double alphaL = std::abs(unL) + cL;
    double alphaR = std::abs(unR) + cR;
    double alpha = std::max(alphaL, alphaR);

    // 3. LLF 
    // F = 0.5*(FL + FR) - 0.5*alpha*(UR - UL)
    State Dissipation = (UR - UL) * (0.5 * alpha);
    State AverageFlux = (FL + FR) * 0.5;

    return AverageFlux - Dissipation;
}

#endif // FLUX_HPP