#include <iostream>
#include <fstream>
#include <string>
#include "Mesh.hpp"
#include "Solver.hpp"

// vtk output
void saveResults(const Mesh& mesh, const std::vector<State>& U, int step) {
    std::string filename = "sol_" + std::to_string(step) + ".vtk";
    std::ofstream file(filename);
    if (!file.is_open()) return;

    file << "# vtk DataFile Version 3.0\n2D Bump\nASCII\nDATASET UNSTRUCTURED_GRID\n";
    
    // Points
    file << "POINTS " << mesh.nodes.size()-1 << " double\n";
    for(size_t i=1; i<mesh.nodes.size(); ++i) 
        file << mesh.nodes[i].x << " " << mesh.nodes[i].y << " 0.0\n";
    
    // Cells
    int listSize = 0;
    for(const auto& c : mesh.cells) listSize += (c.nodes.size() + 1);
    file << "CELLS " << mesh.cells.size() << " " << listSize << "\n";
    for(const auto& c : mesh.cells) {
        file << c.nodes.size();
        for(int n : c.nodes) file << " " << n-1;
        file << "\n";
    }
    
    file << "CELL_TYPES " << mesh.cells.size() << "\n";
    for(const auto& c : mesh.cells) {
        file << (c.nodes.size() == 3 ? "5\n" : "9\n");
    }

    // Data
    file << "CELL_DATA " << mesh.cells.size() << "\n";
    
    file << "SCALARS Mach double 1\nLOOKUP_TABLE default\n";
    for(const auto& u : U) {
        double p = getPressure(u);
        double c = getSoundSpeed(p, u.rho);
        double v = std::sqrt(u.rhou*u.rhou + u.rhov*u.rhov)/u.rho;
        file << v/c << "\n";
    }

    file << "SCALARS Pressure double 1\nLOOKUP_TABLE default\n";
    for(const auto& u : U) file << getPressure(u) << "\n";
}

int main() {
    Mesh mesh;
    // mesh
    mesh.load("bump_1230_t8"); 

    Solver solver(mesh);

    // Ma = 0.5, AoA = 0
    // P_static = 101325 Pa, T_static = 300 K

    solver.setFlowConditions(0.5, 101325.0, 300.0);
    
    solver.initialize();

    // explicit time stepping
    // L and c for calculate CFL number (explicit)
    // dt ~ L / c ~ 0.01 / 340 ~ 3e-5
    
    // double dt = 1e-5; 
    // int maxSteps = 5000;

    // std::cout << "Starting simulation..." << std::endl;
    // for (int i = 0; i <= maxSteps; ++i) {
    //     solver.timeStepExplicit(dt);
      
    //     if (i % 100 == 0) {
    //         std::cout << "Step " << i << std::endl;
    //         saveResults(mesh, solver.getSolution(), i);
    //     }
    // }

    std::cout << "JFNK" << std::endl;
    solver.solveImplicit(1e-5, 2500);
    saveResults(mesh, solver.getSolution(), 9999);

    std::cout << " Grs " << std::endl;
    solver.calculateEntropyError();

    std::cout << " Drag " << std::endl;
    solver.calculateDrag();

    std::cout << "Done" << std::endl;



    return 0;
}