#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>

struct Node { double x, y; };
struct Element { int id; int type; int physTag; std::vector<int> nodes; };

int main() {
    std::string filename = "bump_1230"; // filename ; this is created by code then through Gmsh
    std::ifstream file(filename);
    
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file " << filename << std::endl;
        return 1;
    }

    std::string line;
    int nNodes = 0, nElems = 0;
    std::vector<Node> nodes;
    std::vector<Element> elements;

    // 1. Read Nodes
    while (std::getline(file, line)) {
        if (line == "$Nodes") {
            file >> nNodes;
            nodes.resize(nNodes + 1); // Gmsh indices start at 1
            for (int i = 1; i <= nNodes; ++i) {
                int id; double z;
                file >> id >> nodes[i].x >> nodes[i].y >> z;
            }
            break;
        }
    }

    // 2. Read Elements
    while (std::getline(file, line)) {
        if (line == "$Elements") {
            file >> nElems;
            for (int i = 0; i < nElems; ++i) {
                int id, type, nTags, tag, physTag = 0;
                file >> id >> type >> nTags;
                
                // Read Tags
                for (int j = 0; j < nTags; ++j) {
                    file >> tag;
                    if (j == 0) physTag = tag;
                }

                Element el;
                el.id = id;
                el.type = type;
                el.physTag = physTag;

                // Read nodes based on element type
                int nElNodes = 0;
                if (type == 1) nElNodes = 2;      // Line
                else if (type == 2) nElNodes = 3; // Triangle
                else if (type == 3) nElNodes = 4; // Quad
                else if (type == 15) nElNodes = 1; // Point 

                for (int k = 0; k < nElNodes; ++k) {
                    int nodeId;
                    file >> nodeId;
                    el.nodes.push_back(nodeId);
                }
                
               
                if (nElNodes > 0) elements.push_back(el);
                
                
                std::getline(file, line); 
            }
            break;
        }
    }

    std::cout << "Read successful!" << std::endl;
    std::cout << "Number of nodes: " << nNodes << std::endl;
    std::cout << "Total elements: " << elements.size() << std::endl;
    
    int triCount = 0;
    int inletCount = 0, outletCount = 0, wallCount = 0;

    for (const auto& el : elements) {
        if (el.type == 2) triCount++;
        if (el.type == 1) {
            if (el.physTag == 1) inletCount++;
            if (el.physTag == 2) outletCount++;
            if (el.physTag == 3) wallCount++;
        }
    }

    std::cout << "--- Statistics ---" << std::endl;
    std::cout << "Triangle elements (Domain): " << triCount << std::endl;
    std::cout << "Inlet edges (Inlet ID 1): " << inletCount << std::endl;
    std::cout << "Outlet edges (Outlet ID 2): " << outletCount << std::endl;
    std::cout << "Wall edges (Wall ID 3): " << wallCount << std::endl;

    return 0;
}