#include <iostream>
#include <iomanip>
#include "Flux.hpp"


void printState(const std::string& label, const State& s) {
    std::cout << label << ": [" 
              << s.rho << ", " 
              << s.rhou << ", " 
              << s.rhov << ", " 
              << s.rhoE << "]" << std::endl;
}

int main() {
    std::cout << "=== Testing LLF Flux ===" << std::endl;

    // Case 1: Uniform Flow
    // left and right states are identical
    std::cout << "\n--- Test Case 1: Uniform Flow ---" << std::endl;
    State U_uniform(1.0, 100.0, 0.0, 250000.0); // rho=1, u=100, v=0, p~1e5
    double nx = 1.0, ny = 0.0; // x direction normal vector

    State F_LLF = computeFluxLLF(U_uniform, U_uniform, nx, ny);
    State F_Phys = computeNormalFlux(U_uniform, nx, ny);

    printState("LLF Flux     ", F_LLF);
    printState("Physical Flux", F_Phys);

    
    State diff = F_LLF - F_Phys;
    if (std::abs(diff.rho) < 1e-10 && std::abs(diff.rhoE) < 1e-10) {
        std::cout << ">> Result: PASS (Fluxes match exactly)" << std::endl;
    } else {
        std::cout << ">> Result: FAIL (Fluxes do not match)" << std::endl;
    }

    // Case 2: Shock Discontinuity
    // Left side high pressure stationary, right side low pressure stationary (similar to Sod shock tube initial condition)
    std::cout << "\n--- Test Case 2: Shock Discontinuity ---" << std::endl;
    State UL(1.0, 0.0, 0.0, 250000.0);   // High Pressure
    State UR(0.125, 0.0, 0.0, 25000.0);  // Low Pressure
    
    F_LLF = computeFluxLLF(UL, UR, nx, ny);
    
    printState("Left State ", UL);
    printState("Right State", UR);
    printState("LLF Flux   ", F_LLF);

    // Simple check: mass flux rho*u
    // Since it is stationary gas contact, physical flux is 0, but LLF introduces numerical dissipation
    // Dissipation = -0.5 * alpha * (rho_R - rho_L)
    // alpha = c_sound (approx 340)
    // Flux_rho = 0 - 0.5 * 340 * (0.125 - 1.0) > 0
    // Mass should diffuse from left to right (Flux > 0)
    if (F_LLF.rho > 0) {
        std::cout << ">> Result: PASS (Mass flux direction is correct: High -> Low)" << std::endl;
    } else {
        std::cout << ">> Result: FAIL (Mass flux direction is wrong)" << std::endl;
    }

    return 0;
}